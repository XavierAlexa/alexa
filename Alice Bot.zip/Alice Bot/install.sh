pkg install ffmpeg 
pkg install wget
pkg install nodejs
pkg install npm
npm i -g cwebp && npm i node-tesseract-ocr && npm i -g ytdl && npm i  && npm i got

sudo apt-get install ffmpeg 
sudo apt-get install wget
sudo apt-get install nodejs
sudo apt-get install npm
npm i -g cwebp
npm i node-tesseract-ocr
npm i -g ytdl
npm i
npm i got
node index.js
